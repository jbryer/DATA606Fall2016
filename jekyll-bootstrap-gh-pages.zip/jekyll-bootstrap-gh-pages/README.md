# Jekyll-Bootstrap

The quickest and most hassle-free way to get your new Jekyll powered website up and running.
100% compatible with GitHub pages.

<http://jekyllbootstrap.com>

## Development

Development is active! 

## License

[Creative Commons](http://creativecommons.org/licenses/by-nc-sa/3.0/)
